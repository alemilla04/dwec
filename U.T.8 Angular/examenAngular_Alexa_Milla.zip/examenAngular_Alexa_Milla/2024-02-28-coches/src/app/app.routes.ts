import { Routes } from '@angular/router';
import { FichaInicioComponent } from '../components/ficha-inicio/ficha-inicio.component';
import { FichaMarcasComponent } from '../components/ficha-marcas/ficha-marcas.component';
import { FichaModeloComponent } from '../components/ficha-modelo/ficha-modelo.component';
import { FichaModelosMarcaComponent } from '../components/ficha-modelos-marca/ficha-modelos-marca.component';
import { ListaMarcasComponent } from '../components/lista-marcas/lista-marcas.component';
import { FichaModelosMarcaOcultaComponent } from '../components/ficha-modelos-marca-oculta/ficha-modelos-marca-oculta.component';

export const routes: Routes = [
    { path: '', redirectTo: '/inicio', pathMatch: 'full'},
    { path: 'inicio', component: FichaInicioComponent},
    { path: 'marcas', component: ListaMarcasComponent},
    { path: 'modelo', component: FichaModeloComponent},
    { path: 'modelos', component: FichaModelosMarcaComponent},
    { path: 'modelos/:marcaCod', component: FichaModelosMarcaOcultaComponent},
];
