import { HttpClient } from '@angular/common/http';
import { Injectable, model } from '@angular/core';
import { Observable, find, map, tap } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';

export type MarcaT = {
  codigo: string,
  nombre: string,
}

export type ModeloT = {
  codigo: string,
  nombre: string,
}

@Injectable({
  providedIn: 'root'
})
export class CochesService {

  constructor(private _http: HttpClient) { }

  public getMarcas$(): Observable<MarcaT[]>{
    const url = "http://127.0.0.1:24321/coches/controlador.php?operacion=obtener_marcas";
    return this._http.get(url).pipe(
      //@ts-ignore
      map(response => response.marcas),
      //@ts-ignore
      map(marcas => marcas.map(marca => ({
        codigo: marca.clave,
        nombre: marca.nombre,
      })))
    );
  }

  public getMarcaByCod$(marcaCod: string):Observable<MarcaT> {
    const marcas$ = this.getMarcas$();
    //@ts-ignore
    return marcas$.pipe(
      map(marcas => marcas.find(marca => marca.codigo === marcaCod)),
    );
  }

  public getModelosByMarca$(marca: string): Observable<ModeloT[]>{
    const url = `http://127.0.0.1:24321/coches/controlador.php?operacion=obtener_modelos_marca&marca=${marca}`
    return this._http.get(url).pipe(
      //@ts-ignore
      map(response => response.modelos),
      //@ts-ignore
      map(modelos => modelos.map(modelo=> ({
        codigo: modelo.clave,
        nombre: modelo.nombre,
      }))),
    );
  }

  public getModeloByModeloCod$(modeloClave: string): Observable<ModeloT>{
    const url = `http://127.0.0.1:24321/coches/controlador.php?operacion=obtener_modelo&modelo=${modeloClave}`
    return this._http.get(url).pipe(
      //@ts-ignore
      map(response=>response.modelo),
      map(modelo => ({
        codigo: modelo.clave,
        nombre: modelo.nombre,
      }))
    );
  }
}
