import { Component } from '@angular/core';

@Component({
  selector: 'ficha-inicio',
  standalone: true,
  imports: [],
  templateUrl: './ficha-inicio.component.html',
  styleUrl: './ficha-inicio.component.css'
})
export class FichaInicioComponent {

}
