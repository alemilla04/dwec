import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { CochesService, MarcaT } from '../../services/coches.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'ficha-marcas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ficha-marcas.component.html',
  styleUrl: './ficha-marcas.component.css'
})
export class FichaMarcasComponent {
  marcas$: Observable<MarcaT[]>;

  constructor(private _service: CochesService){
    this.marcas$ = this._service.getMarcas$();
  }
}
