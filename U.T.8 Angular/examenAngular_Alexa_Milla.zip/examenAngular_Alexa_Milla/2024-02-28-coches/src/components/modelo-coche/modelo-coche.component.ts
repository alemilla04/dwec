import { Component, Input, OnInit } from '@angular/core';
import { FichaModeloComponent } from '../ficha-modelo/ficha-modelo.component';
import { CochesService, ModeloT } from '../../services/coches.service';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'modelo-coche',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './modelo-coche.component.html',
  styleUrl: './modelo-coche.component.css'
})
export class ModeloCocheComponent implements OnInit{
  @Input() modeloC: string = "";

  modelo$:Observable<ModeloT> = {} as Observable<ModeloT>;

  constructor(private _service: CochesService){
  }
  ngOnInit(): void {
    this.modelo$ = this._service.getModeloByModeloCod$(this.modeloC);
  }
}
