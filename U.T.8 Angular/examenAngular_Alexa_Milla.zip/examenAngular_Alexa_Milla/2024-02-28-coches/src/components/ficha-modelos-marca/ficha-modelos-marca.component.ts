import { Component, EventEmitter, Output } from '@angular/core';
import { DesplegableMarcasComponent } from '../desplegable-marcas/desplegable-marcas.component';
import { Observable } from 'rxjs';
import { CochesService, ModeloT } from '../../services/coches.service';
import { ModeloCocheComponent } from '../modelo-coche/modelo-coche.component';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'ficha-modelos-marca',
  standalone: true,
  imports: [DesplegableMarcasComponent, ModeloCocheComponent, CommonModule],
  templateUrl: './ficha-modelos-marca.component.html',
  styleUrl: './ficha-modelos-marca.component.css'
})
export class FichaModelosMarcaComponent {
  marcaCod: string = "";
  //@ts-ignore
  modelos$: Observable<ModeloT[]>;

  constructor(private _service: CochesService, private _router: Router){}
  
  //@ts-ignore
  mostrarModelos(e){
    this.marcaCod = e;
    this.modelos$ = this._service.getModelosByMarca$(this.marcaCod);
  }

  //@ts-ignore
  gotoFichaOculta(e){
    this._router.navigate(['/modelos/', this.marcaCod]);
  }
}
