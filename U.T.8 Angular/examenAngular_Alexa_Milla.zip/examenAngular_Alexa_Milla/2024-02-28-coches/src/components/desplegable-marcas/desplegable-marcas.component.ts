import { Component, EventEmitter, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { CochesService, MarcaT, ModeloT } from '../../services/coches.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'desplegable-marcas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './desplegable-marcas.component.html',
  styleUrl: './desplegable-marcas.component.css'
})
export class DesplegableMarcasComponent {
  marcas$: Observable<MarcaT[]>;
  @Output('marcaCambiada') marcaCambiadaEmitter = new EventEmitter<string>();
  constructor(private _service: CochesService){
    this.marcas$ = this._service.getMarcas$();
  }
  //@ts-ignore
  obtenerModelos(e){
    const marcaCod = e.target.value;
    this.marcaCambiadaEmitter.emit(marcaCod);
  }
}
