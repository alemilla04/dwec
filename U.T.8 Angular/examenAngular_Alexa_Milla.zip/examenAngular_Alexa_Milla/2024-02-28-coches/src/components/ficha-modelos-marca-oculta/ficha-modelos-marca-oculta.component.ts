import { Component, OnInit } from '@angular/core';
import { CochesService, MarcaT, ModeloT } from '../../services/coches.service';
import { ActivatedRoute } from '@angular/router';
import { Observable, map } from 'rxjs';
import { CommonModule } from '@angular/common';
import { ModeloCocheComponent } from '../modelo-coche/modelo-coche.component';

@Component({
  selector: 'ficha-modelos-marca-oculta',
  standalone: true,
  imports: [CommonModule, ModeloCocheComponent],
  templateUrl: './ficha-modelos-marca-oculta.component.html',
  styleUrl: './ficha-modelos-marca-oculta.component.css'
})
export class FichaModelosMarcaOcultaComponent implements OnInit{
  marcaCod: string = "";
  modelos$: Observable<ModeloT[]> = {} as Observable<ModeloT[]>;
  marcaNombre: string = "";

  constructor(private _service: CochesService, private _route: ActivatedRoute){}

  ngOnInit(): void {
    //@ts-ignore
    this.marcaCod = this._route.snapshot.paramMap.get("marcaCod");
    this.modelos$ = this._service.getModelosByMarca$(this.marcaCod);
    this._service.getMarcaByCod$(this.marcaCod).subscribe(marca=>this.marcaNombre = marca.nombre);
  }

}
