import { Component } from '@angular/core';
import { FichaMarcasComponent } from '../ficha-marcas/ficha-marcas.component';

@Component({
  selector: 'app-lista-marcas',
  standalone: true,
  imports: [FichaMarcasComponent],
  templateUrl: './lista-marcas.component.html',
  styleUrl: './lista-marcas.component.css'
})
export class ListaMarcasComponent {

}
