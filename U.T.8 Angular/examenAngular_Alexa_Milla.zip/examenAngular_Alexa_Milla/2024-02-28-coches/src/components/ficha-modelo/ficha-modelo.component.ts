import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CochesService, MarcaT, ModeloT } from '../../services/coches.service';
import { ActivatedRoute } from '@angular/router';
import { ModeloCocheComponent } from '../modelo-coche/modelo-coche.component';

@Component({
  selector: 'ficha-modelo',
  standalone: true,
  imports: [ModeloCocheComponent],
  templateUrl: './ficha-modelo.component.html',
  styleUrl: './ficha-modelo.component.css'
})
export class FichaModeloComponent{
  
}
